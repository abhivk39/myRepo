package com.ncs.asset.security;

import com.ncs.asset.dto.LoginDto;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;
import java.util.Date;

import static java.time.temporal.ChronoUnit.DAYS;
import static java.time.temporal.ChronoUnit.MINUTES;

@Component
public class JwtGenerator {


    public String generate(LoginDto loginDto) {

//.setExpiration(Date.from(OffsetDateTime.now().plus(30, MINUTES).toInstant()))
        Claims claims = Jwts.claims()
                .setSubject(loginDto.getUserName());
        claims.put("password", String.valueOf(loginDto.getPassword()));
        claims.put("role", loginDto.getRole());


        return Jwts.builder()
                .setClaims(claims)
                .signWith(SignatureAlgorithm.HS512, "ncsi")
                .compact();
    }
}
