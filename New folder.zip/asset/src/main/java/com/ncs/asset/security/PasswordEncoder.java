/*
 * package com.ncs.asset.security;
 * 
 * import org.mindrot.jbcrypt.BCrypt; import
 * org.springframework.stereotype.Component;
 * 
 * @Component public class PasswordEncoder {
 * 
 * 
 * public static boolean checkPassword(String password,String hashPass) {
 * if(BCrypt.checkpw(password, hashPass)) { return true; } else { return false;
 * } }
 * 
 * 
 * 
 * public static String encryptPassword(String password) { String
 * hashPassword=BCrypt.hashpw(password, BCrypt.gensalt()); return hashPassword;
 * } }
 * 
 * 
 */