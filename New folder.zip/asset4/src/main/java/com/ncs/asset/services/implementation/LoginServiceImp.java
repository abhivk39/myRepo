package com.ncs.asset.services.implementation;


import com.ncs.asset.dto.LoginDto;
import com.ncs.asset.repository.UserRepository;
import com.ncs.asset.services.interfaces.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginServiceImp implements LoginService {

    @Autowired
    UserRepository userRepository;

	@Override
	public String loginAdmin(LoginDto loginDto) {
		// TODO Auto-generated method stub
		return null;
	}


}
